import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, CreditCard, Target, PiggyBank,
  Shield, LogOut, ChevronRight, Zap, Menu, X, Settings, Sun, Moon,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { cn } from '@/lib/utils';
import { useState } from 'react';

const navItems = [
  { href: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/expenses', icon: CreditCard, label: 'Expenses' },
  { href: '/budget', icon: Target, label: 'Budget' },
  { href: '/savings', icon: PiggyBank, label: 'Savings Goals' },
];

function ThemeToggle() {
  const { theme, toggle } = useTheme();
  return (
    <button onClick={toggle} className="sidebar-link w-full">
      {theme === 'dark' ? <Sun className="w-4 h-4 shrink-0" /> : <Moon className="w-4 h-4 shrink-0" />}
      <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>
    </button>
  );
}

function NavContent({ onClose }: { onClose?: () => void }) {
  const location = useLocation();
  const { profile, isAdmin, signOut } = useAuth();

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-5 py-5 border-b border-sidebar-border">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center justify-center w-8 h-8 rounded-lg shrink-0" style={{ background: 'var(--gradient-primary)' }}>
            <Zap className="w-4 h-4 text-primary-foreground" />
          </div>
          <div>
            <span className="font-heading font-bold text-foreground text-lg leading-none">FinPilot</span>
            <p className="text-xs text-muted-foreground mt-0.5">Finance Manager</p>
          </div>
        </div>
        {onClose && (
          <button onClick={onClose} className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors lg:hidden">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        <p className="px-3 pb-1 pt-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Main</p>
        {navItems.map(({ href, icon: Icon, label }) => (
          <Link key={href} to={href} onClick={onClose} className={cn('sidebar-link', location.pathname === href && 'active')}>
            <Icon className="w-4 h-4 shrink-0" />
            <span>{label}</span>
            {location.pathname === href && <ChevronRight className="w-3.5 h-3.5 ml-auto opacity-60" />}
          </Link>
        ))}

        {isAdmin && (
          <>
            <p className="px-3 pb-1 pt-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Admin</p>
            <Link to="/admin" onClick={onClose} className={cn('sidebar-link', location.pathname === '/admin' && 'active')}>
              <Shield className="w-4 h-4 shrink-0" />
              <span>Admin Panel</span>
              {location.pathname === '/admin' && <ChevronRight className="w-3.5 h-3.5 ml-auto opacity-60" />}
            </Link>
          </>
        )}
      </nav>

      <div className="p-3 border-t border-sidebar-border space-y-1">
        <ThemeToggle />
        <Link to="/profile" onClick={onClose} className={cn('sidebar-link', location.pathname === '/profile' && 'active')}>
          <Settings className="w-4 h-4 shrink-0" />
          <span>Settings</span>
        </Link>
        <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg" style={{ background: 'hsl(var(--sidebar-accent))' }}>
          <div className="flex items-center justify-center w-8 h-8 rounded-full shrink-0" style={{ background: 'var(--gradient-primary)' }}>
            <span className="text-xs font-bold text-primary-foreground">{profile?.full_name?.charAt(0)?.toUpperCase() || 'U'}</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-sidebar-accent-foreground truncate">{profile?.full_name || 'User'}</p>
            {isAdmin && <span className="text-xs" style={{ color: 'hsl(var(--primary))' }}>Admin</span>}
          </div>
          <button onClick={signOut} className="p-1.5 rounded-md transition-colors hover:bg-muted text-muted-foreground hover:text-foreground" title="Sign out">
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}

export function Sidebar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      <div className="lg:hidden fixed top-0 left-0 right-0 z-40 flex items-center gap-3 px-4 py-3 border-b border-border" style={{ background: 'hsl(var(--sidebar-background))' }}>
        <button onClick={() => setMobileOpen(true)} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
          <Menu className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center w-6 h-6 rounded-md" style={{ background: 'var(--gradient-primary)' }}>
            <Zap className="w-3 h-3 text-primary-foreground" />
          </div>
          <span className="font-heading font-bold text-foreground text-base">FinPilot</span>
        </div>
      </div>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden" style={{ background: 'hsl(222 47% 3% / 0.7)', backdropFilter: 'blur(4px)' }} onClick={() => setMobileOpen(false)} />
      )}

      <aside className={cn('fixed top-0 left-0 bottom-0 z-50 w-64 lg:hidden transition-transform duration-300', mobileOpen ? 'translate-x-0' : '-translate-x-full')} style={{ background: 'hsl(var(--sidebar-background))', borderRight: '1px solid hsl(var(--sidebar-border))' }}>
        <NavContent onClose={() => setMobileOpen(false)} />
      </aside>

      <aside className="hidden lg:flex flex-col w-64 min-h-screen border-r border-sidebar-border" style={{ background: 'hsl(var(--sidebar-background))' }}>
        <NavContent />
      </aside>
    </>
  );
}
