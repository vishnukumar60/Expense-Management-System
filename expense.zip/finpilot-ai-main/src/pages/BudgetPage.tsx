import { useEffect, useState } from 'react';
import { Save, AlertTriangle, Loader2, Target, TrendingDown, Wallet, Clock } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { AppLayout } from '@/components/layout/AppLayout';

const fmt = (n: number) => n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtShort = (n: number) => n.toLocaleString('en-IN', { maximumFractionDigits: 0 });

const CATEGORIES = ['Food', 'Travel', 'Shopping', 'Subscriptions', 'Education', 'Rent', 'Others'] as const;
const CATEGORY_COLORS: Record<string, string> = {
  Food: 'hsl(193,100%,50%)', Travel: 'hsl(160,100%,45%)', Shopping: 'hsl(270,70%,65%)',
  Subscriptions: 'hsl(38,92%,50%)', Education: 'hsl(200,80%,60%)', Rent: 'hsl(0,72%,51%)', Others: 'hsl(215,20%,55%)',
};
const CATEGORY_EMOJI: Record<string, string> = {
  Food: '🍕', Travel: '✈️', Shopping: '🛍️', Subscriptions: '📱', Education: '📚', Rent: '🏠', Others: '📦',
};

const catKey = (c: string) => `${c.toLowerCase()}_limit` as `${Lowercase<string>}_limit`;

interface Budget {
  id?: string; total_budget: number;
  food_limit: number; travel_limit: number; shopping_limit: number;
  subscriptions_limit: number; education_limit: number; rent_limit: number; others_limit: number;
}

export default function BudgetPage() {
  const { user } = useAuth();
  const now = new Date();
  const [month] = useState(now.getMonth() + 1);
  const [year] = useState(now.getFullYear());
  const [budget, setBudget] = useState<Budget | null>(null);
  const [form, setForm] = useState<Budget>({
    total_budget: 0, food_limit: 0, travel_limit: 0, shopping_limit: 0,
    subscriptions_limit: 0, education_limit: 0, rent_limit: 0, others_limit: 0,
  });
  const [spend, setSpend] = useState<Record<string, number>>({});
  const [totalSpent, setTotalSpent] = useState(0);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => { if (user) fetchData(); }, [user]);

  const fetchData = async () => {
    setLoading(true);
    const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
    const endDate = new Date(year, month, 0).toISOString().split('T')[0];

    const [{ data: budgetData }, { data: expData }] = await Promise.all([
      supabase.from('budgets').select('*').eq('user_id', user!.id).eq('month', month).eq('year', year).single(),
      supabase.from('expenses').select('amount, category').eq('user_id', user!.id).gte('date', startDate).lte('date', endDate),
    ]);

    if (budgetData) { setBudget(budgetData as Budget); setForm(budgetData as Budget); }

    const byCategory: Record<string, number> = {};
    let total = 0;
    (expData || []).forEach((e: { amount: number; category: string }) => {
      byCategory[e.category] = (byCategory[e.category] || 0) + Number(e.amount);
      total += Number(e.amount);
    });
    setSpend(byCategory);
    setTotalSpent(total);
    setLoading(false);
  };

  const handleSave = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!user) return;
    setSaving(true);
    const payload = { ...form, user_id: user.id, month, year };
    const { error } = budget?.id
      ? await supabase.from('budgets').update(payload).eq('id', budget.id)
      : await supabase.from('budgets').upsert(payload, { onConflict: 'user_id,month,year' });

    if (error) toast({ title: 'Error', description: error.message, variant: 'destructive' });
    else { toast({ title: '✅ Budget saved!', description: 'Your budget has been updated.' }); fetchData(); }
    setSaving(false);
  };

  const overallPct = form.total_budget > 0 ? Math.min((totalSpent / form.total_budget) * 100, 100) : 0;
  const daysInMonth = new Date(year, month, 0).getDate();
  const daysLeft = daysInMonth - now.getDate();
  const remaining = form.total_budget - totalSpent;
  const dailyAllowance = daysLeft > 0 ? remaining / daysLeft : 0;

  if (loading) return (
    <AppLayout>
      <div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
    </AppLayout>
  );

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="font-heading font-bold text-2xl text-foreground">Budget Tracker</h1>
          <p className="text-muted-foreground text-sm mt-0.5">
            {new Date(year, month - 1).toLocaleString('en-IN', { month: 'long', year: 'numeric' })} · {daysLeft} days remaining
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { label: 'Total Budget', value: `₹${fmtShort(form.total_budget)}`, icon: <Wallet className="w-5 h-5" />, color: 'hsl(var(--primary))' },
            { label: 'Spent', value: `₹${fmt(totalSpent)}`, icon: <TrendingDown className="w-5 h-5" />, color: 'hsl(var(--destructive))' },
            { label: 'Remaining', value: `₹${fmt(Math.max(remaining, 0))}`, icon: <Target className="w-5 h-5" />, color: 'hsl(var(--accent))' },
            { label: 'Daily Allowance', value: `₹${fmt(Math.max(dailyAllowance, 0))}`, icon: <Clock className="w-5 h-5" />, color: 'hsl(var(--warning))' },
          ].map(({ label, value, icon, color }) => (
            <div key={label} className="stat-card">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-muted-foreground uppercase tracking-wider">{label}</span>
                <div className="p-1.5 rounded-lg" style={{ background: `${color}15`, color }}>{icon}</div>
              </div>
              <div className="font-heading font-bold text-lg" style={{ color }}>{value}</div>
            </div>
          ))}
        </div>

        {form.total_budget > 0 && (
          <div className="glass-card p-5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-foreground">Overall Budget Progress</span>
              <span className="text-sm font-bold" style={{ color: overallPct >= 100 ? 'hsl(var(--destructive))' : overallPct >= 80 ? 'hsl(var(--warning))' : 'hsl(var(--accent))' }}>
                {overallPct.toFixed(1)}%
              </span>
            </div>
            <div className="progress-bar h-3">
              <div className={`progress-fill ${overallPct >= 100 ? 'progress-fill-danger' : overallPct >= 80 ? 'progress-fill-warning' : ''}`} style={{ width: `${overallPct}%` }} />
            </div>
            <div className="flex justify-between mt-2">
              <span className="text-xs text-muted-foreground">₹{fmt(totalSpent)} spent</span>
              <span className="text-xs text-muted-foreground">₹{fmtShort(form.total_budget)} budget</span>
            </div>
            {overallPct >= 80 && (
              <div className="flex items-center gap-2 mt-3 p-2.5 rounded-lg" style={{ background: overallPct >= 100 ? 'hsl(0 72% 51% / 0.08)' : 'hsl(38 92% 50% / 0.08)', border: `1px solid ${overallPct >= 100 ? 'hsl(0 72% 51% / 0.25)' : 'hsl(38 92% 50% / 0.25)'}` }}>
                <AlertTriangle className="w-4 h-4" style={{ color: overallPct >= 100 ? 'hsl(0 72% 51%)' : 'hsl(38 92% 50%)' }} />
                <span className="text-xs" style={{ color: overallPct >= 100 ? 'hsl(0 72% 51%)' : 'hsl(38 92% 50%)' }}>
                  {overallPct >= 100 ? '🚨 Budget exceeded! Time to review spending.' : '⚠️ You\'ve used 80%+ of your budget. Slow down!'}
                </span>
              </div>
            )}
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-5">
          <div className="glass-card p-5">
            <h3 className="font-heading font-semibold text-foreground mb-3">Monthly Total Budget</h3>
            <div className="flex items-center gap-3">
              <span className="text-lg font-semibold text-muted-foreground">₹</span>
              <input type="number" min="0" step="100" className="input-field text-lg font-semibold max-w-xs"
                value={form.total_budget || ''} onChange={e => setForm({ ...form, total_budget: Number(e.target.value) })} placeholder="0" />
            </div>
          </div>

          <div className="glass-card p-5">
            <h3 className="font-heading font-semibold text-foreground mb-4">Category Limits</h3>
            <div className="space-y-4">
              {CATEGORIES.map(cat => {
                const key = catKey(cat);
                const limit = (form as unknown as Record<string, number>)[key] || 0;
                const catSpent = spend[cat] || 0;
                const pct = limit > 0 ? Math.min((catSpent / limit) * 100, 100) : 0;
                const isOver = catSpent > limit && limit > 0;
                const isWarn = pct >= 80 && !isOver;

                return (
                  <div key={cat} className="p-3 rounded-lg" style={{ background: 'hsl(var(--muted) / 0.5)' }}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-base">{CATEGORY_EMOJI[cat]}</span>
                        <span className="text-sm font-medium text-foreground">{cat}</span>
                        {isOver && <span className="badge-health-danger text-[10px]">Over!</span>}
                        {isWarn && <span className="badge-health-warning text-[10px]">80%+</span>}
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground">₹{fmt(catSpent)} spent</span>
                        <div className="flex items-center gap-1">
                          <span className="text-xs text-muted-foreground">₹</span>
                          <input type="number" min="0" step="50" className="input-field w-20 text-sm py-1.5"
                            value={(form as unknown as Record<string, number>)[key] || ''}
                            onChange={e => setForm({ ...form, [key]: Number(e.target.value) })} placeholder="0" />
                        </div>
                      </div>
                    </div>
                    {limit > 0 && (
                      <div className="progress-bar h-1.5">
                        <div className={`progress-fill ${isOver ? 'progress-fill-danger' : isWarn ? 'progress-fill-warning' : ''}`}
                          style={{ width: `${pct}%`, background: isOver || isWarn ? undefined : CATEGORY_COLORS[cat] }} />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <button type="submit" disabled={saving} className="btn-primary w-full sm:w-auto">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {saving ? 'Saving...' : 'Save Budget'}
          </button>
        </form>
      </div>
    </AppLayout>
  );
}
