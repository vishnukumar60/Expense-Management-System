import { useEffect, useState } from 'react';
import { Brain, Loader2, AlertTriangle, TrendingUp, Shield, Zap, Activity, BarChart3, Lightbulb } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { AppLayout } from '@/components/layout/AppLayout';

interface Insight {
  id: string;
  financial_health_score: number | null;
  risk_level: string | null;
  highest_spending_category: string | null;
  burn_rate_prediction: number | null;
  savings_suggestion: string | null;
  insight_summary: string | null;
  anomalies: Array<{ date: string; amount: number; average: number }>;
  created_at: string;
}

export default function AIInsightsPage() {
  const { user } = useAuth();
  const [insights, setInsights] = useState<Insight[]>([]);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);

  useEffect(() => { if (user) fetchInsights(); }, [user]);

  const fetchInsights = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('ai_insights').select('*').eq('user_id', user!.id)
      .order('created_at', { ascending: false }).limit(10);
    setInsights((data || []).map(d => ({ ...d, anomalies: Array.isArray(d.anomalies) ? d.anomalies as Insight['anomalies'] : [] })));
    setLoading(false);
  };

  const runAnalysis = async () => {
    setRunning(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-analyze`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session?.access_token}` },
      });
      if (res.status === 429) throw new Error('Rate limit exceeded. Try again later.');
      if (res.status === 402) throw new Error('AI credits exhausted.');
      if (!res.ok) throw new Error('AI analysis failed');
      toast({ title: '✨ Analysis complete!', description: 'New insights generated.' });
      fetchInsights();
    } catch (err) {
      toast({ title: 'AI Error', description: err instanceof Error ? err.message : 'Failed', variant: 'destructive' });
    } finally {
      setRunning(false);
    }
  };

  const latest = insights[0];

  const scoreColor = (score: number | null) => {
    if (score === null) return 'hsl(var(--muted-foreground))';
    if (score >= 70) return 'hsl(160,100%,45%)';
    if (score >= 40) return 'hsl(38,92%,50%)';
    return 'hsl(0,72%,51%)';
  };

  const scoreLabel = (score: number | null) => {
    if (score === null) return '';
    if (score >= 70) return 'Excellent';
    if (score >= 40) return 'Fair';
    return 'Needs Work';
  };

  const riskBadge = (risk: string | null) => {
    if (risk === 'Low') return 'badge-health-good';
    if (risk === 'High') return 'badge-health-danger';
    return 'badge-health-warning';
  };

  if (loading) return (
    <AppLayout>
      <div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
    </AppLayout>
  );

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="font-heading font-bold text-2xl text-foreground">AI Financial Insights</h1>
            <p className="text-muted-foreground text-sm mt-0.5">Powered by AI · {insights.length} analysis run{insights.length !== 1 ? 's' : ''}</p>
          </div>
          <button onClick={runAnalysis} disabled={running} className="btn-primary">
            {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
            {running ? 'Analyzing...' : 'Run Analysis'}
          </button>
        </div>

        {!latest ? (
          <div className="glass-card p-16 text-center">
            <div className="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-5 animate-pulse-glow" style={{ background: 'var(--gradient-primary)' }}>
              <Brain className="w-10 h-10 text-primary-foreground" />
            </div>
            <h2 className="font-heading font-semibold text-xl text-foreground mb-2">No Analysis Yet</h2>
            <p className="text-muted-foreground mb-6 max-w-sm mx-auto">
              Run your first AI analysis to get personalized financial insights, health score, and spending recommendations.
            </p>
            <button onClick={runAnalysis} disabled={running} className="btn-primary">
              {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
              Start First Analysis
            </button>
          </div>
        ) : (
          <>
            {/* Health Score Hero */}
            <div className="glass-card p-6" style={{ borderColor: 'hsl(var(--primary) / 0.2)' }}>
              <div className="flex items-center gap-2 mb-5">
                <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: 'hsl(var(--primary))' }} />
                <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'hsl(var(--primary))' }}>Latest Analysis</span>
                <span className="text-xs text-muted-foreground ml-auto">
                  {new Date(latest.created_at).toLocaleString()}
                </span>
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
                {/* Health Score */}
                <div className="col-span-2 lg:col-span-1 flex items-center gap-4 p-4 rounded-xl" style={{ background: 'hsl(var(--muted))' }}>
                  <div className="w-16 h-16 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${scoreColor(latest.financial_health_score)}15` }}>
                    <span className="text-3xl font-heading font-bold" style={{ color: scoreColor(latest.financial_health_score) }}>
                      {latest.financial_health_score ?? '—'}
                    </span>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">Health Score</div>
                    <div className="text-sm font-semibold" style={{ color: scoreColor(latest.financial_health_score) }}>
                      {scoreLabel(latest.financial_health_score)}
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl" style={{ background: 'hsl(var(--muted))' }}>
                  <div className="flex items-center gap-2 mb-2">
                    <Shield className="w-4 h-4" style={{ color: 'hsl(var(--primary))' }} />
                    <span className="text-xs text-muted-foreground">Risk Level</span>
                  </div>
                  {latest.risk_level && <span className={riskBadge(latest.risk_level)}>{latest.risk_level}</span>}
                </div>

                <div className="p-4 rounded-xl" style={{ background: 'hsl(var(--muted))' }}>
                  <div className="flex items-center gap-2 mb-2">
                    <Activity className="w-4 h-4" style={{ color: 'hsl(var(--warning))' }} />
                    <span className="text-xs text-muted-foreground">Monthly Burn</span>
                  </div>
                  <div className="font-semibold text-foreground">
                    {latest.burn_rate_prediction ? `$${Number(latest.burn_rate_prediction).toFixed(0)}` : '—'}
                  </div>
                </div>

                <div className="p-4 rounded-xl" style={{ background: 'hsl(var(--muted))' }}>
                  <div className="flex items-center gap-2 mb-2">
                    <BarChart3 className="w-4 h-4" style={{ color: 'hsl(var(--accent))' }} />
                    <span className="text-xs text-muted-foreground">Top Category</span>
                  </div>
                  <div className="font-semibold text-foreground text-sm">{latest.highest_spending_category || '—'}</div>
                </div>
              </div>

              {/* Summary */}
              {latest.insight_summary && (
                <div className="p-4 rounded-xl mb-4" style={{ background: 'hsl(var(--muted))' }}>
                  <div className="flex items-center gap-2 mb-2">
                    <Brain className="w-4 h-4 text-primary" />
                    <span className="text-xs font-semibold uppercase tracking-wider text-primary">AI Summary</span>
                  </div>
                  <p className="text-sm text-foreground leading-relaxed">{latest.insight_summary}</p>
                </div>
              )}

              {/* Savings Suggestion */}
              {latest.savings_suggestion && (
                <div className="flex gap-3 p-4 rounded-xl" style={{ background: 'hsl(var(--accent) / 0.08)', border: '1px solid hsl(var(--accent) / 0.3)' }}>
                  <Lightbulb className="w-5 h-5 shrink-0 mt-0.5" style={{ color: 'hsl(var(--accent))' }} />
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: 'hsl(var(--accent))' }}>Savings Tip</div>
                    <p className="text-sm" style={{ color: 'hsl(var(--accent))' }}>{latest.savings_suggestion}</p>
                  </div>
                </div>
              )}

              {/* Anomalies */}
              {latest.anomalies?.length > 0 && (
                <div className="mt-4 p-4 rounded-xl" style={{ background: 'hsl(0 72% 51% / 0.06)', border: '1px solid hsl(0 72% 51% / 0.2)' }}>
                  <div className="flex items-center gap-2 mb-3">
                    <AlertTriangle className="w-4 h-4" style={{ color: 'hsl(0 72% 51%)' }} />
                    <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'hsl(0 72% 51%)' }}>Spending Anomalies</span>
                  </div>
                  <div className="space-y-2">
                    {latest.anomalies.map((a, i) => (
                      <div key={i} className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{a.date}</span>
                        <span className="font-semibold" style={{ color: 'hsl(0 72% 51%)' }}>
                          ${Number(a.amount).toFixed(2)} <span className="font-normal text-muted-foreground">(avg: ${Number(a.average).toFixed(2)})</span>
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* History */}
            {insights.length > 1 && (
              <div className="glass-card overflow-hidden">
                <div className="px-5 py-4 border-b border-border">
                  <h3 className="font-heading font-semibold text-foreground">Analysis History</h3>
                </div>
                {/* Desktop */}
                <div className="hidden md:block">
                  <table className="w-full">
                    <thead>
                      <tr style={{ borderBottom: '1px solid hsl(var(--border))' }}>
                        {['Date', 'Health Score', 'Risk', 'Monthly Burn', 'Top Category'].map(h => (
                          <th key={h} className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {insights.slice(1).map(ins => (
                        <tr key={ins.id} className="table-row-hover" style={{ borderBottom: '1px solid hsl(var(--border) / 0.5)' }}>
                          <td className="px-4 py-3 text-sm text-muted-foreground">{new Date(ins.created_at).toLocaleDateString()}</td>
                          <td className="px-4 py-3">
                            <span className="font-semibold" style={{ color: scoreColor(ins.financial_health_score) }}>{ins.financial_health_score ?? '—'}</span>
                          </td>
                          <td className="px-4 py-3">
                            {ins.risk_level && <span className={riskBadge(ins.risk_level)}>{ins.risk_level}</span>}
                          </td>
                          <td className="px-4 py-3 text-sm text-foreground">
                            {ins.burn_rate_prediction ? `$${Number(ins.burn_rate_prediction).toFixed(0)}` : '—'}
                          </td>
                          <td className="px-4 py-3 text-sm text-muted-foreground">{ins.highest_spending_category || '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {/* Mobile */}
                <div className="md:hidden divide-y divide-border">
                  {insights.slice(1).map(ins => (
                    <div key={ins.id} className="px-4 py-3 flex items-center justify-between">
                      <div>
                        <p className="text-sm text-foreground">{new Date(ins.created_at).toLocaleDateString()}</p>
                        <p className="text-xs text-muted-foreground">{ins.highest_spending_category || '—'} · {ins.risk_level || '—'} risk</p>
                      </div>
                      <span className="text-lg font-heading font-bold" style={{ color: scoreColor(ins.financial_health_score) }}>
                        {ins.financial_health_score ?? '—'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </AppLayout>
  );
}
