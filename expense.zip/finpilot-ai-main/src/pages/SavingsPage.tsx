import { useEffect, useState } from 'react';
import { Plus, PiggyBank, Loader2, Pencil, Trash2, X, Target, TrendingUp } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { AppLayout } from '@/components/layout/AppLayout';

const fmt = (n: number) => n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtShort = (n: number) => n.toLocaleString('en-IN', { maximumFractionDigits: 0 });

interface Goal {
  id: string; name: string; target_amount: number; current_amount: number;
  target_date: string | null; ai_plan: string | null; created_at: string;
}

export default function SavingsPage() {
  const { user } = useAuth();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Goal | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: '', target_amount: '', current_amount: '', target_date: '' });

  useEffect(() => { if (user) fetchGoals(); }, [user]);

  const fetchGoals = async () => {
    setLoading(true);
    const { data } = await supabase.from('savings_goals').select('*').eq('user_id', user!.id).order('created_at', { ascending: false });
    setGoals((data || []) as Goal[]);
    setLoading(false);
  };

  const openAdd = () => {
    setEditing(null);
    setForm({ name: '', target_amount: '', current_amount: '0', target_date: '' });
    setShowModal(true);
  };

  const openEdit = (g: Goal) => {
    setEditing(g);
    setForm({ name: g.name, target_amount: String(g.target_amount), current_amount: String(g.current_amount), target_date: g.target_date || '' });
    setShowModal(true);
  };

  const handleSave = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!user) return;
    if (Number(form.target_amount) <= 0) { toast({ title: 'Invalid target', variant: 'destructive' }); return; }
    setSaving(true);
    const payload = {
      name: form.name.trim(), target_amount: Number(form.target_amount),
      current_amount: Number(form.current_amount), target_date: form.target_date || null, user_id: user.id,
    };
    const { error } = editing
      ? await supabase.from('savings_goals').update(payload).eq('id', editing.id)
      : await supabase.from('savings_goals').insert(payload);
    if (error) toast({ title: 'Error', description: error.message, variant: 'destructive' });
    else { toast({ title: editing ? 'Goal updated' : 'Goal created!' }); setShowModal(false); fetchGoals(); }
    setSaving(false);
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('savings_goals').delete().eq('id', id);
    if (error) toast({ title: 'Error', description: error.message, variant: 'destructive' });
    else { toast({ title: 'Goal deleted' }); fetchGoals(); }
  };

  const totalTarget = goals.reduce((s, g) => s + Number(g.target_amount), 0);
  const totalSaved = goals.reduce((s, g) => s + Number(g.current_amount), 0);
  const overallPct = totalTarget > 0 ? (totalSaved / totalTarget) * 100 : 0;

  const predictCompletion = (g: Goal): string => {
    const remaining = g.target_amount - g.current_amount;
    if (remaining <= 0) return '🎉 Goal reached!';
    if (!g.target_date) return 'Set a deadline to get a daily savings target';
    const daysLeft = Math.ceil((new Date(g.target_date).getTime() - Date.now()) / 86400000);
    if (daysLeft <= 0) return '⏰ Deadline passed — update your target date';
    const dailyNeeded = remaining / daysLeft;
    return `Save ₹${fmt(dailyNeeded)}/day for ${daysLeft} days to reach your goal`;
  };

  if (loading) return (
    <AppLayout>
      <div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
    </AppLayout>
  );

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="font-heading font-bold text-2xl text-foreground">Savings Goals</h1>
            <p className="text-muted-foreground text-sm mt-0.5">{goals.length} goal{goals.length !== 1 ? 's' : ''} · ₹{fmtShort(totalSaved)} saved</p>
          </div>
          <button onClick={openAdd} className="btn-primary"><Plus className="w-4 h-4" />New Goal</button>
        </div>

        {goals.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="stat-card">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-muted-foreground uppercase tracking-wider">Total Saved</span>
                <div className="p-1.5 rounded-lg" style={{ background: 'hsl(var(--accent) / 0.15)', color: 'hsl(var(--accent))' }}><PiggyBank className="w-5 h-5" /></div>
              </div>
              <div className="font-heading font-bold text-lg" style={{ color: 'hsl(var(--accent))' }}>₹{fmtShort(totalSaved)}</div>
            </div>
            <div className="stat-card">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-muted-foreground uppercase tracking-wider">Total Target</span>
                <div className="p-1.5 rounded-lg" style={{ background: 'hsl(var(--primary) / 0.15)', color: 'hsl(var(--primary))' }}><Target className="w-5 h-5" /></div>
              </div>
              <div className="font-heading font-bold text-lg text-foreground">₹{fmtShort(totalTarget)}</div>
            </div>
            <div className="stat-card">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-muted-foreground uppercase tracking-wider">Progress</span>
                <div className="p-1.5 rounded-lg" style={{ background: 'hsl(var(--warning) / 0.15)', color: 'hsl(var(--warning))' }}><TrendingUp className="w-5 h-5" /></div>
              </div>
              <div className="font-heading font-bold text-lg text-foreground">{overallPct.toFixed(1)}%</div>
              <div className="progress-bar h-1.5 mt-2">
                <div className="progress-fill" style={{ width: `${Math.min(overallPct, 100)}%` }} />
              </div>
            </div>
          </div>
        )}

        {goals.length === 0 ? (
          <div className="glass-card p-16 text-center">
            <PiggyBank className="w-16 h-16 mx-auto mb-4 opacity-20" />
            <h3 className="font-heading font-semibold text-lg text-foreground mb-2">No savings goals yet</h3>
            <p className="text-muted-foreground text-sm mb-5">Set a target and start saving towards your financial goals.</p>
            <button onClick={openAdd} className="btn-primary"><Plus className="w-4 h-4" />Create Your First Goal</button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {goals.map(g => {
              const pct = Math.min((g.current_amount / g.target_amount) * 100, 100);
              const isComplete = g.current_amount >= g.target_amount;
              const daysLeft = g.target_date
                ? Math.ceil((new Date(g.target_date).getTime() - Date.now()) / 86400000)
                : null;

              return (
                <div key={g.id} className="glass-card p-5 flex flex-col gap-4 hover:border-primary/20 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-heading font-semibold text-foreground truncate">{g.name}</h3>
                      {daysLeft !== null && (
                        <span className="text-xs text-muted-foreground">
                          {daysLeft > 0 ? `${daysLeft} days left` : '⏰ Deadline passed'}
                        </span>
                      )}
                    </div>
                    {isComplete && <span className="badge-health-good ml-2 shrink-0">✅ Reached!</span>}
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-1.5">
                      <span className="font-semibold" style={{ color: 'hsl(var(--accent))' }}>₹{fmtShort(g.current_amount)}</span>
                      <span className="text-muted-foreground">/ ₹{fmtShort(g.target_amount)}</span>
                    </div>
                    <div className="progress-bar h-2">
                      <div className="progress-fill" style={{ width: `${pct}%`, background: isComplete ? 'var(--gradient-accent)' : 'var(--gradient-primary)' }} />
                    </div>
                    <div className="flex justify-between mt-1.5">
                      <span className="text-xs text-muted-foreground">{pct.toFixed(1)}% saved</span>
                      <span className="text-xs font-medium text-foreground">₹{fmtShort(Math.max(g.target_amount - g.current_amount, 0))} to go</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2 p-3 rounded-lg" style={{ background: 'hsl(var(--muted))' }}>
                    <Target className="w-3.5 h-3.5 mt-0.5 shrink-0 text-primary" />
                    <p className="text-xs text-muted-foreground leading-relaxed">{predictCompletion(g)}</p>
                  </div>

                  <div className="flex gap-2 mt-auto">
                    <button onClick={() => openEdit(g)} className="btn-secondary flex-1 text-xs py-2">
                      <Pencil className="w-3.5 h-3.5" />Edit
                    </button>
                    <button onClick={() => handleDelete(g.id)} className="btn-danger text-xs py-2 px-3">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4" onClick={() => setShowModal(false)}>
          <div className="fixed inset-0" style={{ background: 'hsl(222 47% 3% / 0.7)', backdropFilter: 'blur(4px)' }} />
          <div className="glass-card w-full sm:max-w-md p-6 animate-fade-in relative rounded-t-2xl sm:rounded-xl" onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 rounded-full bg-border mx-auto mb-4 sm:hidden" />
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-heading font-semibold text-lg text-foreground">{editing ? 'Edit Goal' : 'New Savings Goal'}</h2>
              <button onClick={() => setShowModal(false)} className="btn-ghost p-1.5"><X className="w-4 h-4" /></button>
            </div>
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Goal Name</label>
                <input className="input-field" placeholder="e.g. Emergency Fund" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required maxLength={100} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Target (₹)</label>
                  <input type="number" min="1" step="0.01" className="input-field" value={form.target_amount} onChange={e => setForm({ ...form, target_amount: e.target.value })} required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Saved (₹)</label>
                  <input type="number" min="0" step="0.01" className="input-field" value={form.current_amount} onChange={e => setForm({ ...form, current_amount: e.target.value })} />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Target Date (optional)</label>
                <input type="date" className="input-field" value={form.target_date} onChange={e => setForm({ ...form, target_date: e.target.value })} />
              </div>
              <div className="flex gap-3 pt-1">
                <button type="button" onClick={() => setShowModal(false)} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" disabled={saving} className="btn-primary flex-1">
                  {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                  {editing ? 'Update' : 'Create Goal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AppLayout>
  );
}
