import { useEffect, useState, useCallback } from 'react';
import { Plus, Pencil, Trash2, Search, Filter, ChevronLeft, ChevronRight, Loader2, X, Download, CalendarDays } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { AppLayout } from '@/components/layout/AppLayout';

const fmt = (n: number) => n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const CATEGORIES = ['Food', 'Travel', 'Shopping', 'Subscriptions', 'Education', 'Rent', 'Others'];
const CATEGORY_COLORS: Record<string, string> = {
  Food: 'hsl(193,100%,50%)', Travel: 'hsl(160,100%,45%)', Shopping: 'hsl(270,70%,65%)',
  Subscriptions: 'hsl(38,92%,50%)', Education: 'hsl(200,80%,60%)', Rent: 'hsl(0,72%,51%)', Others: 'hsl(215,20%,55%)',
};
const CATEGORY_EMOJI: Record<string, string> = {
  Food: '🍕', Travel: '✈️', Shopping: '🛍️', Subscriptions: '📱',
  Education: '📚', Rent: '🏠', Others: '📦',
};

interface Expense {
  id: string; amount: number; category: string; note: string | null; date: string; created_at: string;
}

const PAGE_SIZE = 10;

export default function ExpensesPage() {
  const { user } = useAuth();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Expense | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const [total, setTotal] = useState(0);
  const [showFilters, setShowFilters] = useState(false);

  const [filters, setFilters] = useState({ search: '', category: '', minAmount: '', maxAmount: '', dateFrom: '', dateTo: '' });
  const [form, setForm] = useState({ amount: '', category: 'Food', note: '', date: new Date().toISOString().split('T')[0] });
  const [saving, setSaving] = useState(false);

  const activeFilterCount = [filters.search, filters.category, filters.minAmount, filters.maxAmount, filters.dateFrom, filters.dateTo].filter(Boolean).length;

  const fetchExpenses = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    let query = supabase.from('expenses').select('*', { count: 'exact' }).eq('user_id', user.id);
    if (filters.category) query = query.eq('category', filters.category);
    if (filters.minAmount) query = query.gte('amount', Number(filters.minAmount));
    if (filters.maxAmount) query = query.lte('amount', Number(filters.maxAmount));
    if (filters.dateFrom) query = query.gte('date', filters.dateFrom);
    if (filters.dateTo) query = query.lte('date', filters.dateTo);
    if (filters.search) query = query.ilike('note', `%${filters.search}%`);

    const { data, count } = await query
      .order('date', { ascending: false })
      .range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1);

    setExpenses((data || []) as Expense[]);
    setTotal(count || 0);
    setLoading(false);
  }, [user, filters, page]);

  useEffect(() => { fetchExpenses(); }, [fetchExpenses]);

  const openAdd = () => {
    setEditing(null);
    setForm({ amount: '', category: 'Food', note: '', date: new Date().toISOString().split('T')[0] });
    setShowModal(true);
  };

  const openEdit = (e: Expense) => {
    setEditing(e);
    setForm({ amount: String(e.amount), category: e.category, note: e.note || '', date: e.date });
    setShowModal(true);
  };

  const handleSave = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!user) return;
    if (Number(form.amount) <= 0) {
      toast({ title: 'Invalid amount', description: 'Amount must be greater than 0', variant: 'destructive' });
      return;
    }
    setSaving(true);
    const payload = { amount: Number(form.amount), category: form.category, note: form.note || null, date: form.date, user_id: user.id };
    const { error } = editing
      ? await supabase.from('expenses').update(payload).eq('id', editing.id)
      : await supabase.from('expenses').insert(payload);

    if (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: editing ? 'Expense updated' : 'Expense added', description: `₹${fmt(Number(form.amount))} in ${form.category}` });
      setShowModal(false);
      fetchExpenses();
    }
    setSaving(false);
  };

  const handleDelete = async (id: string) => {
    setDeleting(id);
    const { error } = await supabase.from('expenses').delete().eq('id', id);
    if (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Expense deleted' });
      fetchExpenses();
    }
    setDeleting(null);
  };

  const totalPages = Math.ceil(total / PAGE_SIZE);

  const exportCSV = async () => {
    if (!user) return;
    let query = supabase.from('expenses').select('*').eq('user_id', user.id);
    if (filters.category) query = query.eq('category', filters.category);
    if (filters.minAmount) query = query.gte('amount', Number(filters.minAmount));
    if (filters.maxAmount) query = query.lte('amount', Number(filters.maxAmount));
    if (filters.dateFrom) query = query.gte('date', filters.dateFrom);
    if (filters.dateTo) query = query.lte('date', filters.dateTo);
    if (filters.search) query = query.ilike('note', `%${filters.search}%`);
    const { data } = await query.order('date', { ascending: false });
    if (!data || data.length === 0) { toast({ title: 'Nothing to export' }); return; }
    const header = 'Date,Category,Note,Amount (₹)\n';
    const rows = data.map(r => `${r.date},"${r.category}","${(r.note || '').replace(/"/g, '""')}",${r.amount}`).join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'expenses.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  const totalSpentFiltered = expenses.reduce((s, e) => s + Number(e.amount), 0);

  return (
    <AppLayout>
      <div className="space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="font-heading font-bold text-2xl text-foreground">Expenses</h1>
            <p className="text-muted-foreground text-sm mt-0.5">
              {total} transaction{total !== 1 ? 's' : ''} · Page total: ₹{fmt(totalSpentFiltered)}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowFilters(!showFilters)} className="btn-secondary text-sm relative">
              <Filter className="w-4 h-4" />
              <span className="hidden sm:inline">Filters</span>
              {activeFilterCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full text-[10px] font-bold flex items-center justify-center text-primary-foreground" style={{ background: 'var(--gradient-primary)' }}>
                  {activeFilterCount}
                </span>
              )}
            </button>
            <button onClick={exportCSV} className="btn-secondary text-sm">
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">CSV</span>
            </button>
            <button onClick={openAdd} className="btn-primary text-sm">
              <Plus className="w-4 h-4" />
              Add Expense
            </button>
          </div>
        </div>

        {showFilters && (
          <div className="glass-card p-4 animate-fade-in">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
              <div className="sm:col-span-2 lg:col-span-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input type="text" placeholder="Search notes..." className="input-field pl-9"
                  value={filters.search} onChange={e => { setFilters({ ...filters, search: e.target.value }); setPage(0); }} />
              </div>
              <select className="input-field" value={filters.category}
                onChange={e => { setFilters({ ...filters, category: e.target.value }); setPage(0); }}>
                <option value="">All Categories</option>
                {CATEGORIES.map(c => <option key={c}>{c}</option>)}
              </select>
              <input type="number" placeholder="Min ₹" className="input-field" value={filters.minAmount}
                onChange={e => { setFilters({ ...filters, minAmount: e.target.value }); setPage(0); }} />
              <input type="number" placeholder="Max ₹" className="input-field" value={filters.maxAmount}
                onChange={e => { setFilters({ ...filters, maxAmount: e.target.value }); setPage(0); }} />
              <input type="date" className="input-field" value={filters.dateFrom}
                onChange={e => { setFilters({ ...filters, dateFrom: e.target.value }); setPage(0); }} />
              <input type="date" className="input-field" value={filters.dateTo}
                onChange={e => { setFilters({ ...filters, dateTo: e.target.value }); setPage(0); }} />
            </div>
            {activeFilterCount > 0 && (
              <button onClick={() => { setFilters({ search: '', category: '', minAmount: '', maxAmount: '', dateFrom: '', dateTo: '' }); setPage(0); }} className="btn-ghost text-xs mt-2">
                <X className="w-3 h-3" /> Clear all filters
              </button>
            )}
          </div>
        )}

        <div className="glass-card overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center h-48">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : expenses.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <CalendarDays className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p className="font-medium">No expenses found</p>
              <p className="text-xs mt-1">
                {activeFilterCount > 0 ? 'Try adjusting your filters' : 'Click "Add Expense" to get started'}
              </p>
            </div>
          ) : (
            <>
              <div className="hidden md:block">
                <table className="w-full">
                  <thead>
                    <tr style={{ borderBottom: '1px solid hsl(var(--border))' }}>
                      {['Date', 'Category', 'Description', 'Amount', ''].map(h => (
                        <th key={h} className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {expenses.map(e => (
                      <tr key={e.id} className="table-row-hover" style={{ borderBottom: '1px solid hsl(var(--border) / 0.5)' }}>
                        <td className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">
                          {new Date(e.date + 'T00:00:00').toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' })}
                        </td>
                        <td className="px-4 py-3">
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium" style={{ background: `${CATEGORY_COLORS[e.category]}15`, color: CATEGORY_COLORS[e.category], border: `1px solid ${CATEGORY_COLORS[e.category]}30` }}>
                            {CATEGORY_EMOJI[e.category]} {e.category}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm text-muted-foreground max-w-xs truncate">{e.note || '—'}</td>
                        <td className="px-4 py-3 text-sm font-semibold text-foreground">₹{fmt(Number(e.amount))}</td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1 justify-end">
                            <button onClick={() => openEdit(e)} className="btn-ghost p-1.5" title="Edit">
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button onClick={() => handleDelete(e.id)} disabled={deleting === e.id} className="btn-danger p-1.5" title="Delete">
                              {deleting === e.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="md:hidden divide-y divide-border">
                {expenses.map(e => (
                  <div key={e.id} className="flex items-center gap-3 px-4 py-3">
                    <span className="text-xl">{CATEGORY_EMOJI[e.category] || '📦'}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{e.note || e.category}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(e.date + 'T00:00:00').toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })} · {e.category}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-semibold text-foreground">₹{fmt(Number(e.amount))}</p>
                      <div className="flex items-center gap-1 mt-1 justify-end">
                        <button onClick={() => openEdit(e)} className="p-1 text-muted-foreground hover:text-foreground transition-colors">
                          <Pencil className="w-3 h-3" />
                        </button>
                        <button onClick={() => handleDelete(e.id)} disabled={deleting === e.id} className="p-1 text-destructive hover:text-destructive/80 transition-colors">
                          {deleting === e.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Trash2 className="w-3 h-3" />}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-border">
              <span className="text-xs text-muted-foreground">
                {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, total)} of {total}
              </span>
              <div className="flex gap-1">
                <button onClick={() => setPage(p => p - 1)} disabled={page === 0} className="btn-ghost p-1.5 disabled:opacity-40">
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button onClick={() => setPage(p => p + 1)} disabled={page >= totalPages - 1} className="btn-ghost p-1.5 disabled:opacity-40">
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4" onClick={() => setShowModal(false)}>
          <div className="fixed inset-0" style={{ background: 'hsl(222 47% 3% / 0.7)', backdropFilter: 'blur(4px)' }} />
          <div className="glass-card w-full sm:max-w-md p-6 animate-fade-in relative rounded-t-2xl sm:rounded-xl" onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 rounded-full bg-border mx-auto mb-4 sm:hidden" />
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-heading font-semibold text-lg text-foreground">{editing ? 'Edit Expense' : 'New Expense'}</h2>
              <button onClick={() => setShowModal(false)} className="btn-ghost p-1.5"><X className="w-4 h-4" /></button>
            </div>
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Amount (₹)</label>
                <input type="number" step="0.01" min="0.01" className="input-field text-lg font-semibold" placeholder="0.00"
                  value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} required />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Category</label>
                <div className="grid grid-cols-4 gap-2">
                  {CATEGORIES.map(c => (
                    <button key={c} type="button"
                      onClick={() => setForm({ ...form, category: c })}
                      className={`flex flex-col items-center gap-1 p-2.5 rounded-lg text-xs font-medium transition-all border ${form.category === c ? 'border-primary bg-primary/10 text-foreground' : 'border-border bg-muted/30 text-muted-foreground hover:border-primary/30'}`}>
                      <span className="text-base">{CATEGORY_EMOJI[c]}</span>
                      <span className="truncate w-full text-center">{c}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Date</label>
                <input type="date" className="input-field" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} required />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Note (optional)</label>
                <input type="text" className="input-field" placeholder="e.g. Lunch at campus canteen" value={form.note} onChange={e => setForm({ ...form, note: e.target.value })} maxLength={200} />
              </div>
              <div className="flex gap-3 pt-1">
                <button type="button" onClick={() => setShowModal(false)} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" disabled={saving} className="btn-primary flex-1">
                  {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                  {editing ? 'Update' : 'Add Expense'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AppLayout>
  );
}
