import { useEffect, useState } from 'react';
import { Users, CreditCard, Brain, Activity, Loader2, ShieldCheck } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { AppLayout } from '@/components/layout/AppLayout';

interface Stats {
  totalUsers: number;
  totalExpenses: number;
  totalTransactionValue: number;
  totalAIRuns: number;
  recentUsers: Array<{ user_id: string; full_name: string | null; created_at: string }>;
}

export default function AdminPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    fetchStats();
  }, [user]);

  const fetchStats = async () => {
    setLoading(true);
    const [
      { count: userCount },
      { count: expCount, data: expData },
      { count: aiCount },
      { data: recentUsers },
    ] = await Promise.all([
      supabase.from('profiles').select('*', { count: 'exact', head: true }),
      supabase.from('expenses').select('amount', { count: 'exact' }),
      supabase.from('ai_insights').select('*', { count: 'exact', head: true }),
      supabase.from('profiles').select('user_id, full_name, created_at').order('created_at', { ascending: false }).limit(10),
    ]);

    const totalValue = (expData || []).reduce((s: number, e: { amount: number }) => s + Number(e.amount), 0);

    setStats({
      totalUsers: userCount || 0,
      totalExpenses: expCount || 0,
      totalTransactionValue: totalValue,
      totalAIRuns: aiCount || 0,
      recentUsers: (recentUsers || []) as Stats['recentUsers'],
    });
    setLoading(false);
  };

  if (loading) return (
    <AppLayout>
      <div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
    </AppLayout>
  );

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg" style={{ background: 'hsl(var(--primary) / 0.15)' }}>
            <ShieldCheck className="w-5 h-5" style={{ color: 'hsl(var(--primary))' }} />
          </div>
          <div>
            <h1 className="font-heading font-bold text-2xl text-foreground">Admin Panel</h1>
            <p className="text-muted-foreground text-sm">Platform analytics & management</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Total Users', value: stats?.totalUsers ?? 0, icon: <Users className="w-5 h-5" />, color: 'hsl(var(--primary))' },
            { label: 'Total Transactions', value: stats?.totalExpenses ?? 0, icon: <CreditCard className="w-5 h-5" />, color: 'hsl(var(--accent))' },
            { label: 'Transaction Volume', value: `$${(stats?.totalTransactionValue ?? 0).toLocaleString('en', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, icon: <Activity className="w-5 h-5" />, color: 'hsl(var(--warning))' },
            { label: 'AI Analyses Run', value: stats?.totalAIRuns ?? 0, icon: <Brain className="w-5 h-5" />, color: 'hsl(var(--destructive))' },
          ].map(({ label, value, icon, color }) => (
            <div key={label} className="stat-card">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{label}</span>
                <div className="p-1.5 rounded-md" style={{ background: `${color}20`, color }}>{icon}</div>
              </div>
              <div className="font-heading font-bold text-2xl text-foreground">{value}</div>
            </div>
          ))}
        </div>

        {/* Recent Users */}
        <div className="glass-card overflow-hidden">
          <div className="px-5 py-4 border-b border-border">
            <h3 className="font-heading font-semibold text-foreground">Recent Users</h3>
          </div>
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: '1px solid hsl(var(--border))' }}>
                {['User', 'ID', 'Joined'].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(stats?.recentUsers || []).map((u) => (
                <tr key={u.user_id} className="table-row-hover" style={{ borderBottom: '1px solid hsl(var(--border) / 0.5)' }}>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center justify-center w-8 h-8 rounded-full shrink-0 text-xs font-bold text-primary-foreground" style={{ background: 'var(--gradient-primary)' }}>
                        {u.full_name?.charAt(0)?.toUpperCase() || 'U'}
                      </div>
                      <span className="text-sm font-medium text-foreground">{u.full_name || 'Anonymous'}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-xs text-muted-foreground font-mono">{u.user_id.slice(0, 8)}...</td>
                  <td className="px-5 py-3 text-sm text-muted-foreground">
                    {new Date(u.created_at).toLocaleDateString('en', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppLayout>
  );
}
