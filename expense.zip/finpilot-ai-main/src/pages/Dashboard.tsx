import { useEffect, useMemo, useState } from 'react';
import {
  TrendingDown, TrendingUp, Flame,
  AlertTriangle, Loader2, Sparkles, Database,
  ArrowRight, Wallet, PiggyBank, IndianRupee,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import {
  ResponsiveContainer, PieChart, Pie, Cell, Tooltip,
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
} from 'recharts';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { AppLayout } from '@/components/layout/AppLayout';

const fmt = (n: number) => n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtShort = (n: number) => n.toLocaleString('en-IN', { maximumFractionDigits: 0 });

const CATEGORY_COLORS: Record<string, string> = {
  Food: 'hsl(193,100%,50%)', Travel: 'hsl(160,100%,45%)', Shopping: 'hsl(270,70%,65%)',
  Subscriptions: 'hsl(38,92%,50%)', Education: 'hsl(200,80%,60%)', Rent: 'hsl(0,72%,51%)', Others: 'hsl(215,20%,55%)',
};
const CATEGORY_EMOJI: Record<string, string> = {
  Food: '🍕', Travel: '✈️', Shopping: '🛍️', Subscriptions: '📱',
  Education: '📚', Rent: '🏠', Others: '📦',
};
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

interface Expense { id: string; amount: number; category: string; date: string; note?: string | null; }
interface Budget { total_budget: number; month: number; year: number; }
interface SavingsGoal { id: string; name: string; target_amount: number; current_amount: number; }

export default function Dashboard() {
  const { user, profile } = useAuth();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [budget, setBudget] = useState<Budget | null>(null);
  const [goals, setGoals] = useState<SavingsGoal[]>([]);
  const [loading, setLoading] = useState(true);
  const [seedingDemo, setSeedingDemo] = useState(false);

  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();

  useEffect(() => { if (user) fetchData(); }, [user]);

  const fetchData = async () => {
    setLoading(true);
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const [{ data: expData }, { data: budgetData }, { data: goalsData }] = await Promise.all([
      supabase.from('expenses').select('*').eq('user_id', user!.id)
        .gte('date', sixMonthsAgo.toISOString().split('T')[0])
        .order('date', { ascending: false }),
      supabase.from('budgets').select('*').eq('user_id', user!.id)
        .eq('month', currentMonth).eq('year', currentYear).single(),
      supabase.from('savings_goals').select('*').eq('user_id', user!.id)
        .order('created_at', { ascending: false }).limit(3),
    ]);

    setExpenses((expData || []) as Expense[]);
    setBudget(budgetData);
    setGoals((goalsData || []) as SavingsGoal[]);
    setLoading(false);
  };

  const monthlyExpenses = useMemo(
    () => expenses.filter(e => {
      const d = new Date(e.date);
      return d.getMonth() + 1 === currentMonth && d.getFullYear() === currentYear;
    }),
    [expenses, currentMonth, currentYear]
  );

  const totalSpent = useMemo(() => monthlyExpenses.reduce((s, e) => s + Number(e.amount), 0), [monthlyExpenses]);
  const remaining = budget ? Number(budget.total_budget) - totalSpent : null;
  const daysInMonth = new Date(currentYear, currentMonth, 0).getDate();
  const daysPassed = now.getDate();
  const daysLeft = daysInMonth - daysPassed;
  const dailyBurn = daysPassed > 0 ? totalSpent / daysPassed : 0;

  const categoryData = useMemo(() => {
    const map: Record<string, number> = {};
    monthlyExpenses.forEach(e => { map[e.category] = (map[e.category] || 0) + Number(e.amount); });
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [monthlyExpenses]);

  const monthlyBarData = useMemo(() => {
    const map: Record<string, number> = {};
    expenses.forEach(e => {
      const d = new Date(e.date);
      const key = MONTHS[d.getMonth()];
      map[key] = (map[key] || 0) + Number(e.amount);
    });
    return MONTHS.slice(Math.max(0, currentMonth - 6), currentMonth).map(m => ({ month: m, amount: map[m] || 0 }));
  }, [expenses, currentMonth]);

  const budgetPct = budget ? Math.min((totalSpent / Number(budget.total_budget)) * 100, 100) : 0;
  const totalSaved = useMemo(() => goals.reduce((s, g) => s + Number(g.current_amount), 0), [goals]);

  const seedDemoData = async () => {
    if (!user) return;
    setSeedingDemo(true);
    try {
      const y = now.getFullYear();
      const m = now.getMonth() + 1;
      const pad = (n: number) => String(n).padStart(2, '0');

      const demoExpenses = [
        { amount: 450, category: 'Food', note: 'Grocery from BigBasket', date: `${y}-${pad(m)}-01` },
        { amount: 199, category: 'Subscriptions', note: 'Netflix monthly plan', date: `${y}-${pad(m)}-02` },
        { amount: 120, category: 'Food', note: 'Chai & samosa at campus canteen', date: `${y}-${pad(m)}-03` },
        { amount: 2500, category: 'Shopping', note: 'New shoes from Myntra', date: `${y}-${pad(m)}-05` },
        { amount: 8000, category: 'Rent', note: 'Monthly hostel rent', date: `${y}-${pad(m)}-06` },
        { amount: 350, category: 'Travel', note: 'Ola rides this week', date: `${y}-${pad(m)}-08` },
        { amount: 499, category: 'Education', note: 'Udemy Python course', date: `${y}-${pad(m)}-10` },
        { amount: 380, category: 'Food', note: 'Dinner with friends at Barbeque Nation', date: `${y}-${pad(m)}-12` },
        { amount: 119, category: 'Subscriptions', note: 'Spotify premium', date: `${y}-${pad(m)}-14` },
        { amount: 200, category: 'Others', note: 'Laundry and supplies', date: `${y}-${pad(m)}-15` },
      ].map(e => ({ ...e, user_id: user.id }));

      await supabase.from('expenses').insert(demoExpenses);
      await supabase.from('budgets').upsert({
        user_id: user.id, month: m, year: y,
        total_budget: 15000, food_limit: 3000, travel_limit: 1000,
        shopping_limit: 3000, subscriptions_limit: 500,
        education_limit: 1500, rent_limit: 8000, others_limit: 500,
      }, { onConflict: 'user_id,month,year' });
      await supabase.from('savings_goals').insert([
        { user_id: user.id, name: 'Emergency Fund', target_amount: 50000, current_amount: 12000, target_date: `${y}-12-31` },
        { user_id: user.id, name: 'New Laptop', target_amount: 60000, current_amount: 15000, target_date: `${y}-06-30` },
      ]);

      toast({ title: '🎉 Demo data loaded!', description: '10 expenses, budget & savings goals added.' });
      fetchData();
    } catch (err) {
      toast({ title: 'Error', description: err instanceof Error ? err.message : 'Failed', variant: 'destructive' });
    } finally {
      setSeedingDemo(false);
    }
  };

  if (loading) {
    return (
      <AppLayout>
        <div className="flex flex-col items-center justify-center h-64 gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground">Loading your finances...</p>
        </div>
      </AppLayout>
    );
  }

  const greeting = (() => {
    const h = now.getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  })();

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="font-heading font-bold text-2xl lg:text-3xl text-foreground">
              {greeting}, {profile?.full_name?.split(' ')[0] || 'there'} 👋
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              Here's your financial overview for {MONTHS[currentMonth - 1]} {currentYear}
            </p>
          </div>
          {expenses.length === 0 && !budget && (
            <button onClick={seedDemoData} disabled={seedingDemo} className="btn-secondary text-sm">
              {seedingDemo ? <Loader2 className="w-4 h-4 animate-spin" /> : <Database className="w-4 h-4" />}
              {seedingDemo ? 'Loading...' : 'Load Demo Data'}
            </button>
          )}
        </div>

        {/* Onboarding */}
        {expenses.length === 0 && !budget && (
          <div className="glass-card p-6" style={{ borderColor: 'hsl(var(--primary) / 0.3)', background: 'hsl(var(--primary) / 0.04)' }}>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0" style={{ background: 'var(--gradient-primary)' }}>
                <Sparkles className="w-6 h-6 text-primary-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-heading font-semibold text-lg text-foreground mb-1">Welcome to FinPilot! 🚀</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Your personal finance manager is ready. Load demo data to explore, or start adding your own expenses.
                </p>
                <div className="flex flex-wrap gap-2">
                  <button onClick={seedDemoData} disabled={seedingDemo} className="btn-primary text-sm">
                    {seedingDemo ? <Loader2 className="w-4 h-4 animate-spin" /> : <Database className="w-4 h-4" />}
                    Load Demo Data
                  </button>
                  <Link to="/expenses" className="btn-secondary text-sm">Add Expense</Link>
                  <Link to="/budget" className="btn-secondary text-sm">Set Budget</Link>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Stat cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
          <StatCard label="Monthly Budget" value={budget ? `₹${fmtShort(Number(budget.total_budget))}` : 'Not set'} icon={<Wallet className="w-5 h-5" />} color="hsl(var(--primary))" href="/budget" />
          <StatCard label="Total Spent" value={`₹${fmt(totalSpent)}`} icon={<TrendingDown className="w-5 h-5" />} color="hsl(var(--destructive))" sub={budget ? `${budgetPct.toFixed(0)}% of budget` : undefined} href="/expenses" />
          <StatCard label="Remaining" value={remaining !== null ? `₹${fmt(remaining)}` : '—'} icon={<TrendingUp className="w-5 h-5" />} color="hsl(var(--accent))" sub={`${daysLeft} days left`} />
          <StatCard label="Daily Burn Rate" value={`₹${fmt(dailyBurn)}`} icon={<Flame className="w-5 h-5" />} color="hsl(var(--warning))" sub={`${daysPassed} days elapsed`} />
        </div>

        {/* Budget progress */}
        {budget && (
          <div className="glass-card p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <IndianRupee className="w-4 h-4 text-primary" />
                <span className="text-sm font-semibold text-foreground">Budget Usage</span>
              </div>
              <span className="text-sm font-bold" style={{ color: budgetPct >= 100 ? 'hsl(var(--destructive))' : budgetPct >= 80 ? 'hsl(var(--warning))' : 'hsl(var(--accent))' }}>
                {budgetPct.toFixed(1)}%
              </span>
            </div>
            <div className="progress-bar">
              <div className={`progress-fill ${budgetPct >= 100 ? 'progress-fill-danger' : budgetPct >= 80 ? 'progress-fill-warning' : ''}`} style={{ width: `${budgetPct}%` }} />
            </div>
            <div className="flex items-center justify-between mt-2">
              <span className="text-xs text-muted-foreground">₹{fmt(totalSpent)} of ₹{fmtShort(Number(budget.total_budget))}</span>
              {budgetPct >= 80 && (
                <div className="flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" style={{ color: 'hsl(38 92% 50%)' }} />
                  <span className="text-xs font-medium" style={{ color: 'hsl(38 92% 50%)' }}>
                    {budgetPct >= 100 ? 'Over budget!' : 'Almost there'}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Charts row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
          <div className="glass-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-heading font-semibold text-foreground">Spending by Category</h3>
              <Link to="/expenses" className="text-xs font-medium hover:underline" style={{ color: 'hsl(var(--primary))' }}>Details →</Link>
            </div>
            {categoryData.length > 0 ? (
              <div className="flex flex-col sm:flex-row gap-4">
                <ResponsiveContainer width="100%" height={200} className="sm:w-[55%] sm:flex-none">
                  <PieChart>
                    <Pie data={categoryData} cx="50%" cy="50%" innerRadius={55} outerRadius={80} paddingAngle={2} dataKey="value">
                      {categoryData.map((entry) => (<Cell key={entry.name} fill={CATEGORY_COLORS[entry.name] || 'hsl(var(--muted-foreground))'} />))}
                    </Pie>
                    <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', color: 'hsl(var(--foreground))' }} formatter={(v: number) => [`₹${fmt(v)}`, '']} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex flex-wrap sm:flex-col justify-center gap-2 sm:gap-2.5">
                  {categoryData.map((d) => (
                    <div key={d.name} className="flex items-center gap-2 min-w-[120px]">
                      <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: CATEGORY_COLORS[d.name] }} />
                      <span className="text-xs text-muted-foreground flex-1">{CATEGORY_EMOJI[d.name]} {d.name}</span>
                      <span className="text-xs font-semibold text-foreground">₹{fmtShort(d.value)}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-48 text-muted-foreground text-sm">
                <IndianRupee className="w-10 h-10 mb-2 opacity-20" />
                <p>No expenses this month</p>
                <Link to="/expenses" className="text-primary text-xs mt-1 hover:underline">Add your first expense →</Link>
              </div>
            )}
          </div>

          <div className="glass-card p-5">
            <h3 className="font-heading font-semibold text-foreground mb-4">6-Month Spending Trend</h3>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={monthlyBarData}>
                <defs>
                  <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${v}`} />
                <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', color: 'hsl(var(--foreground))' }} formatter={(v: number) => [`₹${fmt(v)}`, 'Spent']} />
                <Area type="monotone" dataKey="amount" stroke="hsl(var(--primary))" fill="url(#areaGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Bottom row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
          <div className="glass-card overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <h3 className="font-heading font-semibold text-foreground">Recent Transactions</h3>
              <Link to="/expenses" className="flex items-center gap-1 text-xs font-medium hover:underline" style={{ color: 'hsl(var(--primary))' }}>View all <ArrowRight className="w-3 h-3" /></Link>
            </div>
            {monthlyExpenses.length > 0 ? (
              <div className="divide-y divide-border">
                {monthlyExpenses.slice(0, 6).map(e => (
                  <div key={e.id} className="flex items-center justify-between px-5 py-3 hover:bg-muted/40 transition-colors">
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="text-lg">{CATEGORY_EMOJI[e.category] || '📦'}</span>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{e.note || e.category}</p>
                        <p className="text-xs text-muted-foreground">{new Date(e.date + 'T00:00:00').toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}</p>
                      </div>
                    </div>
                    <span className="text-sm font-semibold text-foreground whitespace-nowrap ml-3">-₹{fmt(Number(e.amount))}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-muted-foreground text-sm">
                <Wallet className="w-8 h-8 mb-2 opacity-20" />
                <p>No transactions yet</p>
              </div>
            )}
          </div>

          {/* Savings Goals */}
          <div className="glass-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-heading font-semibold text-foreground">Savings Goals</h3>
              <Link to="/savings" className="flex items-center gap-1 text-xs font-medium hover:underline" style={{ color: 'hsl(var(--primary))' }}>Manage <ArrowRight className="w-3 h-3" /></Link>
            </div>
            {goals.length > 0 ? (
              <div className="space-y-3">
                {goals.map(g => {
                  const pct = Math.min((Number(g.current_amount) / Number(g.target_amount)) * 100, 100);
                  return (
                    <div key={g.id}>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium text-foreground truncate mr-2">{g.name}</span>
                        <span className="text-xs text-muted-foreground whitespace-nowrap">₹{fmtShort(Number(g.current_amount))} / ₹{fmtShort(Number(g.target_amount))}</span>
                      </div>
                      <div className="progress-bar h-1.5">
                        <div className="progress-fill" style={{ width: `${pct}%`, background: pct >= 100 ? 'var(--gradient-accent)' : 'var(--gradient-primary)' }} />
                      </div>
                    </div>
                  );
                })}
                <div className="flex items-center justify-between pt-2 border-t border-border">
                  <span className="text-xs text-muted-foreground">Total saved</span>
                  <span className="text-sm font-bold" style={{ color: 'hsl(var(--accent))' }}>₹{fmtShort(totalSaved)}</span>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-6 text-muted-foreground text-sm">
                <PiggyBank className="w-8 h-8 mb-2 opacity-20" />
                <p>No savings goals yet</p>
                <Link to="/savings" className="text-primary text-xs mt-1 hover:underline">Create one →</Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function StatCard({ label, value, icon, color, sub, href }: {
  label: string; value: string; icon: React.ReactNode; color: string; sub?: string; href?: string;
}) {
  const content = (
    <div className="stat-card group cursor-pointer hover:border-primary/20 transition-colors">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{label}</span>
        <div className="p-1.5 rounded-lg" style={{ background: `${color}15`, color }}>{icon}</div>
      </div>
      <div className="font-heading font-bold text-lg lg:text-xl text-foreground">{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-1">{sub}</div>}
    </div>
  );
  return href ? <Link to={href}>{content}</Link> : content;
}
