import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get the user from the auth header
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch user's last 90 days of expenses
    const ninetyDaysAgo = new Date();
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);

    const { data: expenses } = await supabase
      .from("expenses")
      .select("*")
      .eq("user_id", user.id)
      .gte("date", ninetyDaysAgo.toISOString().split("T")[0])
      .order("date", { ascending: false });

    const { data: budget } = await supabase
      .from("budgets")
      .select("*")
      .eq("user_id", user.id)
      .eq("month", new Date().getMonth() + 1)
      .eq("year", new Date().getFullYear())
      .single();

    const { data: goals } = await supabase
      .from("savings_goals")
      .select("*")
      .eq("user_id", user.id);

    // Compute stats
    const totalSpent = expenses?.reduce((s, e) => s + Number(e.amount), 0) || 0;
    const byCategory: Record<string, number> = {};
    expenses?.forEach((e) => {
      byCategory[e.category] = (byCategory[e.category] || 0) + Number(e.amount);
    });
    const highestCategory = Object.entries(byCategory).sort((a, b) => b[1] - a[1])[0];

    // Daily spending for anomaly detection
    const byDay: Record<string, number> = {};
    expenses?.forEach((e) => {
      byDay[e.date] = (byDay[e.date] || 0) + Number(e.amount);
    });
    const dailyValues = Object.values(byDay);
    const dailyAvg = dailyValues.length > 0 ? dailyValues.reduce((a, b) => a + b, 0) / dailyValues.length : 0;
    const anomalies = Object.entries(byDay)
      .filter(([, amt]) => amt > dailyAvg * 2)
      .map(([date, amt]) => ({ date, amount: amt, average: dailyAvg }))
      .slice(0, 3);

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const systemPrompt = `You are a financial AI analyst for FinPilot, a personal finance SaaS for students. 
Analyze the user's financial data and return ONLY valid JSON with no markdown, no explanation.
Required JSON structure:
{
  "financialHealthScore": <integer 0-100>,
  "riskLevel": "<Low|Medium|High>",
  "highestSpendingCategory": "<category name>",
  "burnRatePrediction": <estimated monthly spend as number>,
  "savingsSuggestion": "<actionable 2-sentence suggestion>",
  "insightSummary": "<2-3 sentence narrative summary>"
}`;

    const userPrompt = `Analyze this student's finances:
- Total spent (90 days): $${totalSpent.toFixed(2)}
- Monthly budget: $${budget?.total_budget || 'Not set'}
- Spending by category: ${JSON.stringify(byCategory)}
- Highest category: ${highestCategory ? `${highestCategory[0]}: $${highestCategory[1].toFixed(2)}` : 'None'}
- Daily average spend: $${dailyAvg.toFixed(2)}
- Savings goals: ${goals?.length || 0} active goal(s)
- Spending anomaly days (2x+ average): ${anomalies.length}

Return structured JSON analysis.`;

    // Try models in order
    const models = ["google/gemini-2.5-flash-lite", "google/gemini-2.5-flash", "openai/gpt-5-nano"];
    let aiResponse: Response | null = null;
    
    for (const model of models) {
      aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
          max_tokens: 512,
        }),
      });
      
      if (aiResponse.ok) break;
      if (aiResponse.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (aiResponse.status === 402) continue; // Try next model
    }

    if (!aiResponse || !aiResponse.ok) {
      // Fallback: compute locally without AI
      const healthScore = Math.min(100, Math.max(0, Math.round(
        (budget?.total_budget ? (1 - totalSpent / (budget.total_budget * 3)) * 60 : 40) +
        (goals?.length ? 20 : 0) +
        (anomalies.length === 0 ? 20 : 10)
      )));
      const parsed = {
        financialHealthScore: healthScore,
        riskLevel: healthScore >= 70 ? "Low" : healthScore >= 40 ? "Medium" : "High",
        highestSpendingCategory: highestCategory?.[0] || "Others",
        burnRatePrediction: Math.round(dailyAvg * 30),
        savingsSuggestion: `Your top spending category is ${highestCategory?.[0] || 'unknown'}. Consider setting a strict limit for it and reviewing subscriptions monthly.`,
        insightSummary: `You've spent $${totalSpent.toFixed(0)} over the past 90 days, averaging $${dailyAvg.toFixed(0)}/day. ${anomalies.length > 0 ? `${anomalies.length} unusually high spending day(s) detected.` : 'No spending anomalies detected.'} ${budget ? `You're at ${Math.round((totalSpent / (budget.total_budget * 3)) * 100)}% of your quarterly budget pace.` : ''}`,
      };
      
      const insertData = {
        user_id: user.id,
        financial_health_score: parsed.financialHealthScore,
        risk_level: parsed.riskLevel,
        highest_spending_category: parsed.highestSpendingCategory,
        burn_rate_prediction: parsed.burnRatePrediction,
        savings_suggestion: parsed.savingsSuggestion,
        insight_summary: parsed.insightSummary,
        anomalies,
      };
      await supabase.from("ai_insights").insert(insertData);
      return new Response(JSON.stringify({ ...parsed, anomalies }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiData = await aiResponse.json();
    const rawContent = aiData.choices?.[0]?.message?.content || "{}";
    
    let parsed: Record<string, unknown>;
    try {
      const cleaned = rawContent.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      parsed = JSON.parse(cleaned);
    } catch {
      parsed = {
        financialHealthScore: 50,
        riskLevel: "Medium",
        highestSpendingCategory: highestCategory?.[0] || "Others",
        burnRatePrediction: dailyAvg * 30,
        savingsSuggestion: "Track your spending carefully and set category limits.",
        insightSummary: "Unable to generate detailed insights at this time.",
      };
    }

    // Store insight in database
    const insertData = {
      user_id: user.id,
      financial_health_score: Number(parsed.financialHealthScore) || null,
      risk_level: String(parsed.riskLevel || "Medium"),
      highest_spending_category: String(parsed.highestSpendingCategory || ""),
      burn_rate_prediction: Number(parsed.burnRatePrediction) || null,
      savings_suggestion: String(parsed.savingsSuggestion || ""),
      insight_summary: String(parsed.insightSummary || ""),
      anomalies: anomalies,
    };

    await supabase.from("ai_insights").insert(insertData);

    return new Response(JSON.stringify({ ...parsed, anomalies }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("ai-analyze error:", err);
    return new Response(JSON.stringify({ error: err instanceof Error ? err.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
